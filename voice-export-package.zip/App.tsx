import { useCallback, useEffect, useRef, useState } from 'react';
import { playClip } from './audio/engine';
import type { ClipPlayer } from './audio/engine';
import { resolveTiming, fetchReciterCatalog } from './data/resolver';
import { buildTimeline } from './data/timelineBuilder';
import type { QfChapterReciter } from './data/types';
import { exportClip } from './export/exporter';
import { compareToWindow } from './lib/time';
import type { CaptionTimeline, TimingGranularity, VerseTimelineEntry } from './lib/types/timeline';
import { GRADIENT_PRESETS, drawBackground } from './render/background';
import type { BgImage, GradientPreset } from './render/background';
import { loadFonts } from './render/fonts';
import type { FontSet } from './render/fonts';
import { defaultBounds, drawTransformOverlay, layoutUthmaniText, renderFrame } from './render/renderFrame';
import type { HslColor, SnapState, TextBounds } from './render/renderFrame';
import CropModal from './components/CropModal';
import type { CropAspect } from './components/CropModal';

type Aspect = '9:16' | '1:1';

const ASPECTS: Record<Aspect, { width: number; height: number }> = {
  '9:16': { width: 1080, height: 1920 },
  '1:1': { width: 1080, height: 1080 },
};

const TRANSLATION_ID = 131;
const SNAP_PX = 14;
const MIN_BOX = 60;

function downloadBlob(blob: Blob, name: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export default function App() {
  const [reciters, setReciters] = useState<QfChapterReciter[]>([]);
  const [reciterId, setReciterId] = useState('');
  const [surah, setSurah] = useState(36);
  const [from, setFrom] = useState(1);
  const [to, setTo] = useState(5);
  const [translationEnabled, setTranslationEnabled] = useState(false);
  const [aspect, setAspect] = useState<Aspect>('9:16');
  const [bgId, setBgId] = useState('forest');
  const [timeline, setTimeline] = useState<CaptionTimeline | null>(null);
  const [granularity, setGranularity] = useState<TimingGranularity | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [uthmaniFontReady, setUthmaniFontReady] = useState(true);
  const [scrimEnabled, setScrimEnabled] = useState(false);
  const [wordHighlightEnabled, setWordHighlightEnabled] = useState(false);
  const [transformMode, setTransformMode] = useState(false);
  const [cropImage, setCropImage] = useState<{ url: string; img: HTMLImageElement } | null>(null);
  const [maxWordsPerScreen, setMaxWordsPerScreen] = useState(0);
  const [textColor, setTextColor] = useState<HslColor>({ h: 0, s: 0, l: 100 });
  const [glowColor, setGlowColor] = useState<HslColor>({ h: 38, s: 100, l: 70 });
  const [textOpacity, setTextOpacity] = useState(1);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  const rafRef = useRef(0);
  const playerRef = useRef<ClipPlayer | null>(null);
  const timelineRef = useRef<CaptionTimeline | null>(null);
  const fontsRef = useRef<FontSet>({ uthmani: 'serif', translation: 'sans-serif', uthmaniLoaded: false });
  const bgImageRef = useRef<BgImage>(null);
  const bgPresetRef = useRef<GradientPreset>(GRADIENT_PRESETS[0]);
  const captionsRef = useRef({ uthmani: true, translation: false });
  const boundsRef = useRef<TextBounds>(defaultBounds(1080, 1920));
  const snapRef = useRef<SnapState>({ x: false, y: false });
  const dragRef = useRef<{
    type: 'move' | 'resize';
    corner: string;
    startX: number;
    startY: number;
    orig: TextBounds;
  } | null>(null);
  const scrimRef = useRef(false);
  const wordHighlightRef = useRef(false);
  const transformModeRef = useRef(false);
  const isExportingRef = useRef(false);
  const maxWordsRef = useRef(0);
  const textColorRef = useRef<HslColor>({ h: 0, s: 0, l: 100 });
  const glowColorRef = useRef<HslColor>({ h: 38, s: 100, l: 70 });
  const textOpacityRef = useRef(1);

  captionsRef.current = { uthmani: true, translation: translationEnabled };
  bgPresetRef.current = GRADIENT_PRESETS.find((p) => p.id === bgId) ?? GRADIENT_PRESETS[0];
  scrimRef.current = scrimEnabled;
  wordHighlightRef.current = wordHighlightEnabled;
  transformModeRef.current = transformMode;
  isExportingRef.current = isExporting;
  maxWordsRef.current = maxWordsPerScreen;
  textColorRef.current = textColor;
  glowColorRef.current = glowColor;
  textOpacityRef.current = textOpacity;

  const size = ASPECTS[aspect];

  useEffect(() => {
    boundsRef.current = defaultBounds(size.width, size.height);
  }, [size.width, size.height]);

  const buildSeq = useRef(0);

  const build = useCallback(
    async (rid: string, s: number, f: number, t: number, trans: boolean) => {
      if (!rid) return;
      if (s < 1 || s > 114 || f < 1 || t < 1 || f > t) {
        setError('Invalid verse range (1 <= from <= to)');
        return;
      }
      const seq = ++buildSeq.current;
      setIsLoading(true);
      setError(null);
      try {
        const resolution = await resolveTiming({ reciterId: rid, surah: s, verses: [f, t] });
        const tl = await buildTimeline(
          {
            range: { surah: s, from: f, to: t },
            reciterId: rid,
            captions: {
              uthmani: true,
              translation: { enabled: trans, translationId: TRANSLATION_ID, language: 'en' },
            },
          },
          resolution,
        );
        if (seq !== buildSeq.current) return;
        timelineRef.current = tl;
        setTimeline(tl);
        setGranularity(tl.meta.granularity);
        if (resolution.warnings.length > 0) {
          setError(resolution.warnings.join('; '));
        }
      } catch (err) {
        if (seq !== buildSeq.current) return;
        setError((err as Error).message);
      } finally {
        if (seq === buildSeq.current) setIsLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    fetchReciterCatalog()
      .then((rs) => {
        setReciters(rs);
        if (rs.length > 0) setReciterId(String(rs[0].id));
      })
      .catch((err) => setError((err as Error).message));
  }, []);

  useEffect(() => {
    build(reciterId, surah, from, to, translationEnabled);
  }, [reciterId, surah, from, to, translationEnabled, build]);

  useEffect(() => {
    loadFonts().then((fonts) => {
      fontsRef.current = fonts;
      setUthmaniFontReady(fonts.uthmaniLoaded);
    });
  }, []);

  useEffect(() => {
    if (!timeline || !timeline.meta.audioUrl) return;
    const dur =
      timeline.verses.length > 0 ? timeline.verses[timeline.verses.length - 1].endSeconds : undefined;
    let cancelled = false;
    playClip(timeline.meta.audioUrl, timeline.meta.clipStartOffsetSeconds, dur)
      .then((p) => {
        if (cancelled) {
          p.stop();
          return;
        }
        p.element.addEventListener('ended', () => setIsPlaying(false));
        playerRef.current = p;
      })
      .catch((err) => setError((err as Error).message));
    return () => {
      cancelled = true;
      playerRef.current?.stop();
      playerRef.current = null;
      setIsPlaying(false);
    };
  }, [timeline]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctxRef.current = ctx;
    const loop = () => {
      const p = playerRef.current;
      const t = p ? p.timeSeconds() : 0;
      const tl = timelineRef.current;
      if (tl) {
        renderFrame(ctx, {
          tSeconds: t,
          timeline: tl,
          captionsOn: captionsRef.current,
          fonts: fontsRef.current,
          bounds: boundsRef.current,
          scrimEnabled: scrimRef.current,
          wordHighlightEnabled: wordHighlightRef.current,
          maxWordsPerScreen: maxWordsRef.current,
          textColor: textColorRef.current,
          glowColor: glowColorRef.current,
          textOpacity: textOpacityRef.current,
          drawBackground: (c) => drawBackground(c, bgPresetRef.current, bgImageRef.current),
        });
      } else {
        drawBackground(ctx, bgPresetRef.current, bgImageRef.current);
      }
      if (transformModeRef.current && !isExportingRef.current) {
        drawTransformOverlay(ctx, boundsRef.current, snapRef.current);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  const toLogicalPoint = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const r = canvas.getBoundingClientRect();
    return {
      x: (clientX - r.left) * (canvas.width / r.width),
      y: (clientY - r.top) * (canvas.height / r.height),
    };
  };

  const measureTextBlock = (box: TextBounds): { width: number; height: number } | null => {
    const ctx = ctxRef.current;
    const tl = timelineRef.current;
    if (!ctx || !tl) return null;
    const t = playerRef.current?.timeSeconds() ?? 0;
    let verse: VerseTimelineEntry | null = null;
    for (const v of tl.verses) {
      if (compareToWindow(t, v.startSeconds, v.endSeconds) === 0) {
        verse = v;
        break;
      }
    }
    if (!verse) return null;
    const info = layoutUthmaniText(ctx, verse, {
      fonts: fontsRef.current,
      boxW: box.width,
      boxH: box.height,
      align: 'center',
      atMinFont: true,
    });
    return { width: info.width, height: info.height };
  };

  const RESIZE_CURSOR: Record<string, string> = {
    tl: 'nwse-resize',
    br: 'nwse-resize',
    tr: 'nesw-resize',
    bl: 'nesw-resize',
    l: 'ew-resize',
    r: 'ew-resize',
    t: 'ns-resize',
    b: 'ns-resize',
  };

  const applyCursor = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const d = dragRef.current;
    let cursor = 'default';
    if (d) {
      cursor = d.type === 'move' ? 'grabbing' : RESIZE_CURSOR[d.corner] ?? 'default';
    } else if (transformModeRef.current) {
      const p = toLogicalPoint(clientX, clientY);
      const b = boundsRef.current;
      const corner = hitBoxHandle(b, p);
      if (corner) {
        cursor = RESIZE_CURSOR[corner] ?? 'default';
      } else if (p.x >= b.x && p.x <= b.x + b.width && p.y >= b.y && p.y <= b.y + b.height) {
        cursor = 'move';
      }
    }
    canvas.style.cursor = cursor;
  };

  const hitBoxHandle = (b: TextBounds, p: { x: number; y: number }): string | null => {
    const h = Math.max(18, Math.round(size.width * 0.022));
    const corners: { id: string; x: number; y: number }[] = [
      { id: 'tl', x: b.x, y: b.y },
      { id: 'tr', x: b.x + b.width, y: b.y },
      { id: 'bl', x: b.x, y: b.y + b.height },
      { id: 'br', x: b.x + b.width, y: b.y + b.height },
    ];
    for (const c of corners) {
      if (Math.abs(p.x - c.x) <= h && Math.abs(p.y - c.y) <= h) return c.id;
    }
    const edges: { id: string; x: number; y: number }[] = [
      { id: 'l', x: b.x, y: b.y + b.height / 2 },
      { id: 'r', x: b.x + b.width, y: b.y + b.height / 2 },
      { id: 't', x: b.x + b.width / 2, y: b.y },
      { id: 'b', x: b.x + b.width / 2, y: b.y + b.height },
    ];
    for (const c of edges) {
      if (Math.abs(p.x - c.x) <= h && Math.abs(p.y - c.y) <= h) return c.id;
    }
    return null;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!transformModeRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const p = toLogicalPoint(e.clientX, e.clientY);
    const b = boundsRef.current;
    const corner = hitBoxHandle(b, p);
    if (corner) {
      dragRef.current = { type: 'resize', corner, startX: p.x, startY: p.y, orig: { ...b } };
    } else if (p.x >= b.x && p.x <= b.x + b.width && p.y >= b.y && p.y <= b.y + b.height) {
      dragRef.current = { type: 'move', corner: '', startX: p.x, startY: p.y, orig: { ...b } };
    } else {
      return;
    }
    applyCursor(e.clientX, e.clientY);
    canvas.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const d = dragRef.current;
    if (!d) return;
    const p = toLogicalPoint(e.clientX, e.clientY);
    const W = size.width;
    const H = size.height;
    const dx = p.x - d.startX;
    const dy = p.y - d.startY;
    let nx = d.orig.x;
    let ny = d.orig.y;
    let nw = d.orig.width;
    let nh = d.orig.height;
    if (d.type === 'move') {
      nx = Math.min(Math.max(d.orig.x + dx, 0), W - nw);
      ny = Math.min(Math.max(d.orig.y + dy, 0), H - nh);
      const cx = nx + nw / 2;
      const cy = ny + nh / 2;
      const snapX = Math.abs(cx - W / 2) < SNAP_PX;
      const snapY = Math.abs(cy - H / 2) < SNAP_PX;
      if (snapX) nx = W / 2 - nw / 2;
      if (snapY) ny = H / 2 - nh / 2;
      snapRef.current = { x: snapX, y: snapY };
    } else {
      const anchorX = d.corner.includes('l') ? d.orig.x + d.orig.width : d.orig.x;
      const anchorY = d.corner.includes('t') ? d.orig.y + d.orig.height : d.orig.y;
      const dirX = d.corner.includes('l') ? -1 : d.corner.includes('r') ? 1 : 0;
      const dirY = d.corner.includes('t') ? -1 : d.corner.includes('b') ? 1 : 0;
      const maxW = dirX === -1 ? anchorX : W - anchorX;
      const maxH = dirY === -1 ? anchorY : H - anchorY;
      nw = dirX === 0 ? d.orig.width : Math.min(Math.max(dirX * (p.x - anchorX), MIN_BOX), maxW);
      nh = dirY === 0 ? d.orig.height : Math.min(Math.max(dirY * (p.y - anchorY), MIN_BOX), maxH);
      const text = measureTextBlock({ x: 0, y: 0, width: nw, height: nh });
      if (text) {
        nw = Math.max(nw, Math.ceil(text.width));
        nh = Math.max(nh, Math.ceil(text.height));
      }
      nw = Math.min(nw, maxW);
      nh = Math.min(nh, maxH);
      nx = dirX === -1 ? anchorX - nw : anchorX;
      ny = dirY === -1 ? anchorY - nh : anchorY;
      snapRef.current = { x: false, y: false };
    }
    boundsRef.current = { x: nx, y: ny, width: nw, height: nh };
    applyCursor(e.clientX, e.clientY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    dragRef.current = null;
    snapRef.current = { x: false, y: false };
    applyCursor(e.clientX, e.clientY);
  };

  const handlePointerLeave = () => {
    if (!dragRef.current) {
      const canvas = canvasRef.current;
      if (canvas) canvas.style.cursor = 'default';
    }
  };

  const handlePlayPause = useCallback(async () => {
    let p = playerRef.current;
    const tl = timelineRef.current;
    if (!p && tl && tl.meta.audioUrl) {
      try {
        const dur = tl.verses.length > 0 ? tl.verses[tl.verses.length - 1].endSeconds : undefined;
        p = await playClip(tl.meta.audioUrl, tl.meta.clipStartOffsetSeconds, dur);
        p.element.addEventListener('ended', () => setIsPlaying(false));
        playerRef.current = p;
      } catch (err) {
        setError((err as Error).message);
        return;
      }
    }
    if (!p) return;
    if (isPlaying) {
      p.pause();
      setIsPlaying(false);
    } else {
      await p.play();
      setIsPlaying(true);
    }
  }, [isPlaying]);

  const handleStop = useCallback(() => {
    const p = playerRef.current;
    if (!p) return;
    p.pause();
    p.element.currentTime = timelineRef.current?.meta.clipStartOffsetSeconds ?? 0;
    setIsPlaying(false);
  }, []);

  const handleBgImage = useCallback((file: File | null) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => setCropImage({ url, img });
    img.onerror = () => URL.revokeObjectURL(url);
    img.src = url;
  }, []);

  const handleCropCancel = useCallback(() => {
    setCropImage((cur) => {
      if (cur) URL.revokeObjectURL(cur.url);
      return null;
    });
  }, []);

  const handleCropConfirm = useCallback((canvas: HTMLCanvasElement) => {
    setCropImage((cur) => {
      if (cur) URL.revokeObjectURL(cur.url);
      return null;
    });
    bgImageRef.current = canvas;
  }, []);

  const [audioWarning, setAudioWarning] = useState<string | null>(null);

  const handleExport = useCallback(async () => {
    const tl = timelineRef.current;
    const ctx = ctxRef.current;
    if (!tl) {
      setError('No timeline loaded — load a recitation range first');
      return;
    }
    if (!ctx) {
      setError('Canvas not initialised — please reload the page');
      return;
    }
    if (!tl.meta.audioUrl) {
      setError('No audio source available for this recitation');
      return;
    }
    setIsExporting(true);
    setExportProgress(0);
    setAudioWarning(null);
    try {
      const duration = tl.verses[tl.verses.length - 1].endSeconds;
      const result = await exportClip({
        width: ctx.canvas.width,
        height: ctx.canvas.height,
        durationSeconds: duration,
        audioUrl: tl.meta.audioUrl,
        clipStartOffsetSeconds: tl.meta.clipStartOffsetSeconds,
        render: {
          timeline: tl,
          captionsOn: captionsRef.current,
          fonts: fontsRef.current,
          bounds: boundsRef.current,
          scrimEnabled: scrimRef.current,
          wordHighlightEnabled: wordHighlightRef.current,
          maxWordsPerScreen: maxWordsRef.current,
          textColor: textColorRef.current,
          glowColor: glowColorRef.current,
          textOpacity: textOpacityRef.current,
          drawBackground: (c) => drawBackground(c, bgPresetRef.current, bgImageRef.current),
        },
        onProgress: (p) => {
          if (p.phase === 'render') setExportProgress(p.ratio * 0.85);
          else if (p.phase === 'audio') setExportProgress(0.85 + p.ratio * 0.12);
          else setExportProgress(0.97 + p.ratio * 0.03);
        },
      });
      if (!result.hasAudio) {
        setAudioWarning('Exported video has no audio — audio encoding was unavailable in this browser context');
      }
      downloadBlob(result.blob, `quran-${tl.meta.surah}-${tl.meta.versesFrom}-${tl.meta.versesTo}.mp4`);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsExporting(false);
      setExportProgress(0);
    }
  }, []);

  const durSeconds =
    timeline && timeline.verses.length > 0
      ? timeline.verses[timeline.verses.length - 1].endSeconds
      : 0;

  return (
    <div style={{ display: 'flex', gap: 24, padding: 24, height: '100%' }}>
      <main style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <canvas
          ref={canvasRef}
          width={size.width}
          height={size.height}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          onPointerLeave={handlePointerLeave}
          style={{
            height: '100%',
            maxHeight: 720,
            aspectRatio: `${size.width} / ${size.height}`,
            borderRadius: 12,
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
            touchAction: 'none',
          }}
        />
      </main>

      <aside style={{ width: 320, display: 'flex', flexDirection: 'column', gap: 12 }}>
        <h1 style={{ margin: 0, fontSize: 20 }}>Quranic Video Generator</h1>

        <label>
          Reciter
          <select
            value={reciterId}
            onChange={(e) => setReciterId(e.target.value)}
            style={inputStyle}
          >
            {reciters.map((r) => (
              <option key={r.id} value={String(r.id)}>
                {r.name}
                {r.style?.name ? ` — ${r.style.name}` : ''}
              </option>
            ))}
          </select>
        </label>

        <div style={{ display: 'flex', gap: 8 }}>
          <label style={{ flex: 1 }}>
            Surah
            <input
              type="number"
              min={1}
              max={114}
              value={surah}
              onChange={(e) => setSurah(Number(e.target.value))}
              style={inputStyle}
            />
          </label>
          <label style={{ flex: 1 }}>
            From ayah
            <input
              type="number"
              min={1}
              max={286}
              value={from}
              onChange={(e) => setFrom(Math.max(1, Number(e.target.value)))}
              style={inputStyle}
            />
          </label>
          <label style={{ flex: 1 }}>
            To ayah
            <input
              type="number"
              min={1}
              max={286}
              value={to}
              onChange={(e) => setTo(Math.max(1, Number(e.target.value)))}
              style={inputStyle}
            />
          </label>
        </div>

        <label>
          Format
          <select value={aspect} onChange={(e) => setAspect(e.target.value as Aspect)} style={inputStyle}>
            <option value="9:16">Vertical 9:16 (1080x1920)</option>
            <option value="1:1">Square 1:1 (1080x1080)</option>
          </select>
        </label>

        <label>
          Background
          <select value={bgId} onChange={(e) => setBgId(e.target.value)} style={inputStyle}>
            {GRADIENT_PRESETS.map((g) => (
              <option key={g.id} value={g.id}>
                {g.label}
              </option>
            ))}
          </select>
        </label>

        <label>
          Background image
          <input
            type="file"
            accept="image/*"
            onChange={(e) => handleBgImage(e.target.files?.[0] ?? null)}
            style={inputStyle}
          />
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={translationEnabled}
            onChange={(e) => setTranslationEnabled(e.target.checked)}
          />
          Show translation
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={scrimEnabled}
            onChange={(e) => setScrimEnabled(e.target.checked)}
          />
          Caption background (scrim)
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={wordHighlightEnabled}
            onChange={(e) => setWordHighlightEnabled(e.target.checked)}
          />
          Word-by-word highlight
        </label>

        <label>
          Max words per screen (0 = disabled)
          <input
            type="number"
            min={0}
            max={50}
            value={maxWordsPerScreen}
            onChange={(e) => setMaxWordsPerScreen(Math.max(0, Number(e.target.value)))}
            style={inputStyle}
          />
        </label>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ width: 24, height: 24, borderRadius: 4, background: `hsl(${textColor.h}, ${textColor.s}%, ${textColor.l}%)`, border: '1px solid #30363d', flexShrink: 0 }} />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>Text H: {textColor.h}</label>
            <input type="range" min={0} max={360} value={textColor.h} onChange={(e) => setTextColor((c) => ({ ...c, h: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>S: {textColor.s}%</label>
            <input type="range" min={0} max={100} value={textColor.s} onChange={(e) => setTextColor((c) => ({ ...c, s: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>L: {textColor.l}%</label>
            <input type="range" min={0} max={100} value={textColor.l} onChange={(e) => setTextColor((c) => ({ ...c, l: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div style={{ width: 24, height: 24, borderRadius: 4, background: `hsl(${glowColor.h}, ${glowColor.s}%, ${glowColor.l}%)`, border: '1px solid #30363d', flexShrink: 0 }} />
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>Glow H: {glowColor.h}</label>
            <input type="range" min={0} max={360} value={glowColor.h} onChange={(e) => setGlowColor((c) => ({ ...c, h: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>S: {glowColor.s}%</label>
            <input type="range" min={0} max={100} value={glowColor.s} onChange={(e) => setGlowColor((c) => ({ ...c, s: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <label style={{ fontSize: 11, opacity: 0.7 }}>L: {glowColor.l}%</label>
            <input type="range" min={0} max={100} value={glowColor.l} onChange={(e) => setGlowColor((c) => ({ ...c, l: Number(e.target.value) }))} style={{ width: '100%' }} />
          </div>
        </div>

        <label>
          Text opacity: {Math.round(textOpacity * 100)}%
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(textOpacity * 100)}
            onChange={(e) => setTextOpacity(Number(e.target.value) / 100)}
            style={{ ...inputStyle, padding: '6px 0' }}
          />
        </label>

        <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <input
            type="checkbox"
            checked={transformMode}
            onChange={(e) => setTransformMode(e.target.checked)}
          />
          Text transform (drag / resize on canvas)
        </label>
        {transformMode && (
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Drag inside the box to move it · drag an edge handle to resize one dimension, or a corner
            to resize both · the box never shrinks past its text. Overlay is hidden during export.
          </div>
        )}

        {granularity && (
          <div style={{ fontSize: 13, opacity: 0.8 }}>
            Timing: <strong>{granularity}</strong> · Duration: {durSeconds.toFixed(1)}s
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={handlePlayPause} disabled={!timeline || isExporting} style={buttonStyle}>
            {isPlaying ? 'Pause' : 'Play'}
          </button>
          <button onClick={handleStop} disabled={!timeline || isExporting} style={buttonStyle}>
            Stop
          </button>
          <button onClick={handleExport} disabled={!timeline || isExporting} style={buttonStyle}>
            {isExporting ? `Exporting ${Math.round(exportProgress * 100)}%` : 'Export MP4'}
          </button>
        </div>

        {isLoading && <div style={{ fontSize: 13, opacity: 0.8 }}>Loading timeline…</div>}
        {!uthmaniFontReady && (
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Note: Uthmani font file not found — add{' '}
            <code>public/fonts/KFGQPC-Uthmanic-HAFS.otf</code> for the official script
            (currently falling back to Scheherazade New).
          </div>
        )}
        {error && <div style={{ fontSize: 13, color: '#fca5a5' }}>{error}</div>}
        {audioWarning && <div style={{ fontSize: 12, color: '#fbbf24' }}>{audioWarning}</div>}
        {isExporting && (
          <div style={{ fontSize: 12, opacity: 0.8 }}>
            <div style={{ width: '100%', height: 6, background: '#30363d', borderRadius: 3, marginBottom: 4 }}>
              <div
                style={{
                  width: `${Math.round(exportProgress * 100)}%`,
                  height: '100%',
                  background: '#1f6feb',
                  borderRadius: 3,
                  transition: 'width 250ms ease',
                }}
              />
            </div>
            Keep this tab in the foreground during export.
          </div>
        )}
      </aside>

      {cropImage && (
        <CropModal
          image={cropImage.img}
          defaultAspect={aspect as CropAspect}
          onAspectChange={(a) => setAspect(a as Aspect)}
          onConfirm={handleCropConfirm}
          onCancel={handleCropCancel}
        />
      )}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  display: 'block',
  width: '100%',
  marginTop: 4,
  padding: '6px 8px',
  background: '#161b22',
  color: '#e7e7e7',
  border: '1px solid #30363d',
  borderRadius: 6,
};

const buttonStyle: React.CSSProperties = {
  padding: '8px 14px',
  background: '#1f6feb',
  color: '#fff',
  border: 'none',
  borderRadius: 6,
  fontWeight: 600,
};